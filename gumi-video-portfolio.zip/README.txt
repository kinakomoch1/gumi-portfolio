GUMI 動画編集ポートフォリオ

1. index.html の末尾にある CONFIG を編集し、動画URLとメール・Xを設定。
2. index.html をブラウザで開くとプレビューできます。
3. 公開: GitHub の公開リポジトリに index.html をアップロードし、Settings > Pages > Deploy from a branch > main / (root) を選択。
4. 数分後、https://ユーザー名.github.io/リポジトリ名/ で公開されます。

※サイトは静的HTMLで、動画そのものはYouTube等にアップロードしてURLを設定してください。
